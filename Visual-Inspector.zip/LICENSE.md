CANVASFLIP CONFIDENTIAL
__________________

 Copyright (C) CanvasFlip Solutions Private Limited
 All Rights Reserved.
 Proprietary and confidential.

NOTICE: All information contained herein is, and remains the property of
CanvasFlip Solutions Private Limited. The intellectual and technical concepts
contained herein are proprietary to CanvasFlip Solutions Private Limited
and may be covered by Patents, patents in process, and are protected copyright law.
Dissemination of this information or reproduction of this material via any medium
is strictly forbidden unless prior written permission is obtained from
CanvasFlip Solutions Private Limited.